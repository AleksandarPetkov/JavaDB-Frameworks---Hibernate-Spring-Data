package alararestaurant.domain.entities;

public enum OrderType {
    ForHere,
    ToGo
}
